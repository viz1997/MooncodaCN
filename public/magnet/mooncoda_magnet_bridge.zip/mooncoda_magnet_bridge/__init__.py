# -*- coding: utf-8 -*-
"""Mooncoda 磁吸孔桥接插件(Mooncoda Magnet Bridge)

这是**装成 Blender 插件**用的入口 —— 实现在同目录的 `bridge.py` 里
(跟网页给的那份 `blender_bridge.py` 是同一个文件,构建时拷进来的)。

装法:Edit → Preferences → Add-ons → Install from Disk… → 选
`mooncoda_magnet_bridge.zip` → 勾上启用。

启用之后桥接**自动就起了**;要手动开关:3D 视图右侧(N 面板)→ Mooncoda。
端口在 Preferences → Add-ons → Mooncoda Magnet Bridge 里改。

⚠️ **别改这个文件里的东西** —— 改 `bridge.py`(仓库里的
`public/magnet/blender_bridge.py`)之后要重新构建:`pnpm magnet:addon`。
"""

from .bridge import bl_info, register, unregister  # noqa: F401

__all__ = ["bl_info", "register", "unregister"]
