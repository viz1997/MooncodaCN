# 把打印引擎装进你的项目

这个 zip 解开就是一个自包含的目录:`print-tool-core/`。

里面**只有纯计算**:模型检测(焊接 / 拓扑 / 自检摘要 / WJP 报告)、
克重(耗材 / 支撑 / 模型单位判定)、报价(定价引擎 / 交期档位 / 取整 /
浮雕档位 / 智能摆盘)。

**没有** React 组件、three.js 视口、next-intl 文案、数据库、支付、模型上传
—— 那些是**界面 / 应用层**的事,各项目自己做。

## 装法一:拷进你的项目(最省事)

```bash
unzip print-tool-core.zip -d /你的项目/
# 得到 /你的项目/print-tool-core/src/**
```

包里的 import **全是相对路径** ⇒ 拷到哪儿都能编译。

给你自己的项目加一条路径别名(这样 import 好看):

```jsonc
// tsconfig.json
{
  "compilerOptions": {
    "paths": {
      "print-tool-core/*": ["./print-tool-core/src/*"]
    }
  }
}
```

然后:

```ts
import { computePrintQuote } from "print-tool-core/quote/compute-quote";
import { weldAndAnalyzeTopology } from "print-tool-core/mesh/weld";
import { detectModelUnitScale } from "print-tool-core/weight/model-units";
```

> **Vitest / Vite 也得配一条同样的 alias** —— 它们的解析器不读
> tsconfig 的 paths(除非你专门接了插件)。

## 装法二:当依赖装(不想动自己的目录结构)

```bash
pnpm add file:./print-tool-core
# 或者 npm i file:./print-tool-core
```

然后按包名引:

```ts
import { computePrintQuote } from "@mooncoda/print-tool-core/quote/compute-quote";
```

⚠️ 这个包是 **source-first**(`main` 指的是 `./src/index.ts`,不是
`dist/`)⇒ 宿主项目直接吃 TS 源码。Next.js / Vite / webpack 都行;
**别用** `"type": "module"` 之类的 ESM-only 工具链(这个包是 CJS 口径)。

想发成真正的 JS 产物:

```bash
cd print-tool-core
npx tsc -p tsconfig.build.json
# 产出 dist/ —— 然后把 package.json 的 main / types 改成 ./dist/index.js
```

## 两条口径(改之前先读)

1. **金额一律「分」,一律向上取整** —— `quote/rounding.ts`。
   `ceilCents()` / `yuanToCentsCeil()` 是唯一的两个入口(浮点误差用
   `1e-9` 的 epsilon 挡掉,`-0` 归一化成 `+0`)。
2. **服务端不信客户端带来的价** —— `computePrintQuote()` **只吃几何**
   (体积 / 表面积 / 尺寸 / 支撑克重),价格永远由服务端那一份 `settings`
   算出来。客户端报的单价一律不认。

## 几个容易踩的坑

- **`supportWeightG` 一定要算出来再提交** —— 服务端按
  `input.supportWeightG ?? 0` 算支撑费,少了它支撑费算成 **0**(少收钱)。
- **浮雕档位是钱的口径,不是显示细节** —— 浮雕 1mm 托底、手办 5mm 托底,
  托底**算进支撑体积** ⇒ 算进支撑克重 ⇒ 算进支撑加价。
  判定在 `pricing/relief-detect.ts`(纯几何)。
- **模型单位要先判** —— AI 导出的模型坐标常常是**归一化的**(±1),不是毫米。
  `detectModelUnitScale()` 看**最大边**判(≥10mm 当毫米),归一化到
  最大边 100mm。详见 `weight/model-units.ts`。
- **支撑外壳是「某个姿态下的一次结果」** —— 姿态变了手里那块就作废,
  得按新姿态重算。`SupportShellData.pose` 带着算它时的姿态。

## 许可

MIT
